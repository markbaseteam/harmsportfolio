# Leeruitkomsten

## 1. Analysis

*You are able to carry out a requirement analysis for a software system with various stakeholders in a context of existing systems. And, you can define acceptance criteria based on quality properties and a risk analysis carried out with, among others, attention for security aspects.*

#### Iteratie 0
Voor dit onderwerp zal ik komende iteratie de data van home assistant gaan analyseren. Hiervoor heeft Home Assistant een [data science pagina](https://data.home-assistant.io/) waar in ze het een en ander uitleggen over de data binnen het platform. Ook kan ik hiervoor mijn persoonlijke data set analyseren. 

Wat ik uit de analyse wil halen is voornamelijk welke data bruikbaar is, wat mogelijke lables zijn en of er al globale verbindingen te leggen zijn tussen triggers en entitys. 

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --- | --- | --- | --- | --- | 
|   x  |     |     |     |     |

Dit onderwerp is nog niet behandeld en zal in iteratie 1 op Orienting of Beginning komen. 

---
## 2. Advice

*You are able to give advice concerning the choice of software architecture or existing software frameworks whereby cost aspects and quality properties such as availability, performance, security and scalability play a role. And, you can provide advice about the approach to take during the processing and consultation of large quantities of data with attention for privacy. Moreover, you are able to provide advice on the organisation of a software development process, including the test process.*

#### Iteratie 0
In iteratie 1 zal ik een eerste advies maken hoe de data binnen home assistant gebruikt kan worden om gebruikers gedrag te herkennen. Dit zal ik na de analyse doen. 


### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --- | --- | --- | --- | --- | 
|   x  |     |     |     |     |

Dit onderwerp is nog niet behandeld en zal in iteratie 1 op Orienting of Beginning komen. 

---
## 3. Design

*You are able to compile a software architecture for a software system that is comprised of existing and new systems, and takes several stakeholders quality properties into account, including security and scalability, as well as able to compile a test strategy for system tests.*

#### Iteratie 0
Voor dit onderwerp heb ik meer onderzoek nodig om te weten hoe ik dit kan gaan aantonen binnen dit project

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --- | --- | --- | --- | --- | 
|   x  |     |     |     |     |

Dit onderwerp is nog niet behandeld

---
## 4. Implementation

*You are able to build and make available a scalable software system that correlates with existing systems, perhaps in the cloud, according to the designed architecture while using existing frameworks. You are able to apply test automation in carrying out tests.*

#### Iteratie 0
Door verschillende proof of concepts te maken ga in aantonen dat ik begrijp hoe een machine learning model werkt en getraind kan worden. 


### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --- | --- | --- | --- | --- | 
|   x  |     |     |     |     |

Dit onderwerp is nog niet behandeld

---
## 5. Management

*You are able to carry out configuration, change and release management in conjunction with infrastructure management. You can organize a development environment with automated build and test infrastructure.*

### Iteratie 0

#### samenwerken

Deze iteratie hebben we een eerste opzet gemaakt voor het samenwerken. We hebben hiervoor een [jira project](https://prophecy1.atlassian.net/jira/software/projects/AA/boards/2) voor aangemaakt en een [Github project](https://github.com/S7HaMachineLearning)

Het doel is om de taakverdeling in het jira project bij te houden door middel van agile/scrum toe te passen. Ieder maakt voor zijn eigen onderzoeksvraag een epic aan. Onder deze epics komen mijn eigen stories te staan. Zie [hier](https://prophecy1.atlassian.net/jira/software/projects/AA/boards/2/roadmap?assignee=6093ea8b539c14006ad73f38) de lijst met mijn aangemaakte epics en stories.  

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --------- | --------- | --------- | ---------- | -------- |
|           | X         |           |            |          |

Qua management heb ik mezelf beoordeeld met oriënterend. Er is een omgeving waaruit het ontwikkelwerk word gemanaged maar dit moet nog in gebruik genomen worden

---
## 6. Judgement

*You are able to formulate appropriate research questions and secondary questions based on an unstructured practical issue, in all stages of the methodical process, and you are able to independently select research methods, carry them out and substantiate them with reference to research strategies in order to demonstrate the soundness of his research. Moreover you demonstrate that you are considerate towards social, international, scientific and ethical aspects in your analysis.*

### Iteratie 0

In iteratie 0 heb ik verschillende [onderzoeksvragen](https://github.com/S7HaMachineLearning/documentation/blob/main/README.md#onderzoeksvraag-1-hvg:~:text=Onderzoeksvraag%201%20HvG) geformuleerd. Met bijbehorende potentiële [onderzoeksmethoden](https://github.com/S7HaMachineLearning/documentation/blob/main/README.md#onderzoeksvraag-1-hvg:~:text=op%20onderstaande%20onderzoeksvragen.-,Potentiele%20onderzoeksmethode%3A,-(ictresearchmethods.nl)).  Deze zal ik in komende iteraties gaan toepassen in mijn onderzoek. Op basis van mijn onderzoek zal in aannames gaan doen waaruit zal gaan blijken wat mijn niveau zal zijn voor dit leerdoel 

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --------- | --------- | --------- | ---------- | -------- |
|           | X         |           |            |          |

Voor dit onderdeel beoordeel ik mijzelf met Orienting. Ik heb in iteratie 0 verschillende onderzoeksvragen geformuleerd en meerdere malen hier op gereflecteerd en zo nodig aangepast. Om een hoger niveau in dit onderwerp te behalen zal ik de onderzoeksmethoden die ik heb gekozen moeten gaan toepassen en een aanname gaan doen op basis van mijn onderzoek. 

---
## 7. Communication

*You are able to account for and defend the execution of a comprehensive professional assignment carried out in a realistic context, both orally and in writing, and are able to adapt the writing style to the intended audience either in Dutch or in English. Also, you are able to work effectively in a team in the independent execution of a professional assignment. Moreover you are able to function and work well in an international or intercultural environment, inside as well as outside the university of applied sciences.*

### iteratie 0 

#### Communicatie naar buiten

In deze iteratie is er veel gecommuniceerd rondom het project. Samen met Bastiaan en Bram heb ik ons idee voorgelegt aan Leon en Mark. Mijn twijfel op dat moment was voornamelijk of het onderwerp te splitsen was tussen ons 3e. Hier hebben we over gespart en besloten om het project wat te gaan uit werken. 

Nadat we het project wat hebben uit gewerkt hebben we dit ook gepitcht voor de klas en [feedback](https://fhict.instructure.com/courses/12928/external_tools/1067) opgehaald. Uit de feedback is voornamelijk naar voren gekomen dat het project gesplitst kan worden in 3 aparte onderdelen. Wel moeten we goed opletten dat er een duidelijke scheiding is tussen ons werk. In het hoofdstuk [Management](#5.%20Management#Iteratie%200) dieper op in gegaan.

Na de classicale pitch is de volgende stap om het project concreter te gaan maken. We hebben hiervoor de Fontys template gebruikt. Vervolgens zijn we weer feedback gaan ophalen bij de docenten. Omdat het project nu verder is uitgewerkt kan er concretere vragen gesteld worden en concretere feedback gegeven worden. Hier op word in **checkpoint 1** van [feedpulse](https://fhict.instructure.com/courses/12928/external_tools/1067) verder gereflecteerd. 

Als laatste in deze iteratie hebben we een [presentatie]([documentation/Automated automations presentatie 27022023.pdf at main · S7HaMachineLearning/documentation (github.com)](https://github.com/S7HaMachineLearning/documentation/blob/main/Presentaties/Automated%20automations%20presentatie%2027022023.pdf)) gegeven aan de klas en docenten over ons project. Hierop reflecteren we in **checkpoint 2** van [feedpulse](https://fhict.instructure.com/courses/12928/external_tools/1067). 

Wat ik heb opgemaakt uit alle feedback die we hebben ontvangen is dat het project ambitieus is en dat we goed in de gaten moeten houden of het project haalbaar is in combinatie van machine learning. Hiervoor is het belangrijk dat we goed blijven communiceren over de voortgang. Ook moeten we scherp blijven op het splitsen van onze werkzaamheden en afspraken maken over onderlinge afhankelijkheden.

#### communicatie binnen het project

Binnen het project hebben Bastiaan, Bram regelmatig contact momenten. Voor deze contact momenten zijn we nog zoekende hoe we het beste onze afspraken kunnen vastleggen. Dit kan bijvoorbeeld door een notule.

#### Iteratie 0

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --------- | --------- | --------- | ---------- | -------- |
|           |    X      |           |            |          |

Op dit moment vind ik dat ik nog aan het oriënteren ben met de communicatie.

We halen wel feedback op maar dit moet nog meer structuur krijgen. We kunnen als groep gerichtere vragen stellen waardoor de frequentie wat omlaag kan. Daarnaast weet ik nog niet in welke vorm we het project blijven updaten klasikaal of een op een met de docenten.  

Onderling moeten we nog structuur gaan aanbrengen. Hiervoor zou het goed zijn om iets van een notulen te maken per meeting zodat we afspraken vastleggen. 

---
## 8. Learning ability


*You are able to describe your professional talents and development ambitions in relation to the ICT profession, as well as able to reflect and receive feedback on your own performance in the ICT profession. You demonstrate initiative, and you have an independent attitude in which you work independently and in a result-oriented manner on professional assignments outside of the university of applied sciences.*

### Iteratie 0

Voor de start van iteratie 0 had ik nog geen basiskennis van machine learning. Na wat kort onderzoek op het web heb ik een idee wat je er mee kan en hoe/waar je het kan toepassen. In de komende iteraties (vanaf iteratie 1) ga ik dieper in op de materie Om zo daadwerkelijk te kunnen gaan bepalen of er een AI technologie is die ik kan gaan gebruiken voor dit project. 

### Conclusie

| Undefined | Orienting | Beginning | Proficient | Advanced |
| --------- | --------- | --------- | ---------- | -------- |
|           | X         |           |            |          |

In iteratie 0 heb ik enkel oriënterende onderzoekjes gedaan over machine learning. Het lijkt mij dan ook passend om hier een beoordeling Orienting te geven.